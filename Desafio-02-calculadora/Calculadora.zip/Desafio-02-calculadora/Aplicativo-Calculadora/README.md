# Aplicativo-Calculadora
Desafio 02 da disciplina "Programação de App".
